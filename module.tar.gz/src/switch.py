from typing import ClassVar, Mapping, Sequence, Any, Dict, Optional, Tuple, Final, List, cast
from typing_extensions import Self
from typing import Final
from viam.module.types import Reconfigurable
from viam.proto.app.robot import ComponentConfig
from viam.proto.common import ResourceName, Vector3
from viam.resource.base import ResourceBase
from viam.resource.types import Model, ModelFamily
from viam.components.generic import Generic
from viam.logging import getLogger
from dotenv import load_dotenv
from kasa import SmartPlug
from kasa import Discover

import time
import asyncio
import os

load_dotenv()
LOGGER = getLogger(__name__)

plug_ip = os.getenv("SMART_PLUG_IP") or ''

plug = SmartPlug(plug_ip)

class switch(Generic, Reconfigurable):
    
    """
    Generic component, which represents any type of component that can executes arbitrary commands
    """


    MODEL: ClassVar[Model] = Model(ModelFamily("joyce", "kasa"), "switch")
    
    # create any class parameters here, 'some_pin' is used as an example (change/add as needed)
    some_pin: int

    # Constructor
    @classmethod
    def new(cls, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]) -> Self:
        my_class = cls(config.name)
        my_class.reconfigure(config, dependencies)
        return my_class

    # Validates JSON Configuration
    @classmethod
    def validate(cls, config: ComponentConfig):
        # here we validate config, the following is just an example and should be updated as needed
        return

    # Handles attribute reconfiguration
    def reconfigure(self, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]):
        # here we initialize the resource instance, the following is just an example and should be updated as needed
        return

    """ Implement the methods the Viam RDK defines for the Generic API (rdk:component:generic) """

async def toggle_switch(self):
        """
        Toggle switch on or off.
        """

        if True: 
            LOGGER.info('Turning On.')
            await plug.turn_on()
        else:
            LOGGER.info('Turning Off.')
            await plug.turn_off()


